#!/bin/sh

user=`whoami`

# Clean up old chroot
sudo umount root/data
sudo umount root/q
mount | grep `pwd`/root/data > /dev/null && { echo "$root/data still mounted!" ; exit 1; }
mount | grep `pwd`/root/q > /dev/null && { echo "$root/q still mounted!" ; exit 1; }
sudo rm -rf root

sudo cp -r root_install root
mkdir -p data
mkdir -p q
sudo chown -R $user root
cat /etc/passwd | grep -i $user >> root/etc/passwd
sudo mount -o bind data root/data
sudo mount -o bind q root/q
sudo mknod -m 666 root/dev/null c 1 3
sudo mknod -m 444 root/dev/urandom c 1 9

sudo chroot --userspec=$user root q /q/procs/m.q
