#!/bin/sh
export QHOME=/opt/q
export SSL_VERIFY_SERVER=NO
LD_PRELOAD=/opt/q/hostname_fix.so taskset -c 0 /opt/q/l64/q $@
